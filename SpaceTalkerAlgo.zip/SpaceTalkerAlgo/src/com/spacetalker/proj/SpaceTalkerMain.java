package com.spacetalker.proj;

import java.util.HashMap;
import java.util.Scanner;

public class SpaceTalkerMain {

	public static void main(String[] args) {
		SpaceTalkerMain spaceT = new SpaceTalkerMain();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the roman numeral received from our exoplanetary friends: ");
		String roman = scanner.nextLine(); 
		int res = spaceT.spaceTalkerAlgo(roman);
		System.out.println("Hindu�Arabic_numeral_system equivalent of '" + roman +"' is: "+res);
		scanner.close();
	}
	
	public int spaceTalkerAlgo(String roman){
		HashMap<Character, Integer> conv = new HashMap<Character, Integer>();
		conv.put('I',1);
		conv.put('V',5);
		conv.put('X',10);
		conv.put('L',50);
		conv.put('C',100);
		conv.put('D',500);
		conv.put('M',1000);
		int res = 0;
		for (int i=0; i<roman.length(); i++) {
			if(i<roman.length()-1) {
			if(conv.get(roman.charAt(i))>=conv.get(roman.charAt(i+1))) {
			res = res+conv.get(roman.charAt(i));
			}
			else if(conv.get(roman.charAt(i))<conv.get(roman.charAt(i+1))) {
			res=res+((conv.get(roman.charAt(i+1)))-conv.get(roman.charAt(i)));
			i++;
			}
			}
			else if(i==roman.length()-1) {
				res = res+conv.get(roman.charAt(i));				
				}		
			}
		return res;
	}

}
