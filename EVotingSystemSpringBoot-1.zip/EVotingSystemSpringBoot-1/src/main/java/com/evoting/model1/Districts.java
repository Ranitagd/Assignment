package com.evoting.model1;

import java.util.HashMap;

public class Districts {	

	private String DElecDate;
	private String DMember;
	private HashMap<Integer, String> DList;
	private HashMap<String, String> DParty;
	private String DName;
	private int Did;
	private String DParties;
	private String VotingDist;
	public String getVotingDist() {
		return VotingDist;
	}
	public void setVotingDist(String votingDist) {
		VotingDist = votingDist;
	}
	public String getDParties() {
		return DParties;
	}
	public void setDParties(String dParties) {
		DParties = dParties;
	}
	public String getDMember() {
		return DMember;
	}
	public void setDMember(String dMember) {
		DMember = dMember;
	}
	public HashMap<String, String> getDParty() {
		return DParty;
	}
	public void setDParty(HashMap<String, String> dParty) {
		DParty = dParty;
	}
	public HashMap<Integer, String> getDList() {
		return DList;
	}
	public void setDList(HashMap<Integer, String> dList) {
		DList = dList;
	}
	public String getDName() {
		return DName;
	}
	public void setDName(String dName) {
		DName = dName;
	}
	public int getDid() {
		return Did;
	}
	public void setDid(int did) {
		Did = did;
	}
	public String getDElecDate() {
		return DElecDate;
	}
	public void setDElecDate(String dElecDate) {
		DElecDate = dElecDate;
	}		

}
