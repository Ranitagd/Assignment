package com.evoting.model1;

public class Voter {

	private String email;
	private String voterCardNum;
	private String fName;
	private String password;
	private String district;
	private String votedParty;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getVoterCardNum() {
		return voterCardNum;
	}
	public void setVoterCardNum(String voterCardNum) {
		this.voterCardNum = voterCardNum;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getVotedParty() {
		return votedParty;
	}
	public void setVotedParty(String votedParty) {
		this.votedParty = votedParty;
	}
	
}
