package com.evoting.model1;

public class Election {

	private String District;
	private String Party;
	private String Voter;
	private String PartyMmber;
	private String Votes;
	public String getVotes() {
		return Votes;
	}
	public void setVotes(String votes) {
		Votes = votes;
	}
	public String getDistrict() {
		return District;
	}
	public void setDistrict(String district) {
		District = district;
	}
	public String getParty() {
		return Party;
	}
	public void setParty(String party) {
		Party = party;
	}
	public String getVoter() {
		return Voter;
	}
	public void setVoter(String voter) {
		Voter = voter;
	}
	public String getPartyMmber() {
		return PartyMmber;
	}
	public void setPartyMmber(String partyMmber) {
		PartyMmber = partyMmber;
	}
}
