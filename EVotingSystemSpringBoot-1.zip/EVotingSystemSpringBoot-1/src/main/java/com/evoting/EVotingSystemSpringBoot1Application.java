package com.evoting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EVotingSystemSpringBoot1Application {

	public static void main(String[] args) {
		SpringApplication.run(EVotingSystemSpringBoot1Application.class, args);
	}

}
