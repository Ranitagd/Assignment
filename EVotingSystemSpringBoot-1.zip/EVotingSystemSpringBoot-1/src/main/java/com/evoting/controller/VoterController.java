package com.evoting.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.evoting.model1.Districts;
import com.evoting.model1.Election;
import com.evoting.model1.Voter;

@RestController
public class VoterController {
	
//POST method for registration using Voter Card Number of voter using bean Voter
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String Register(@RequestBody Voter inputPayload) {
		String response = "The voter named" + inputPayload.getfName() 
		+ " having id " + inputPayload.getVoterCardNum()+" has been created successfully!!";
		return response;
	}
	
//GET list of Districts where election is taking place
	@RequestMapping(value = "/districtList", method = RequestMethod.GET)
	public HashMap<Integer, String> DList() {
		Districts district = new Districts();
		HashMap<Integer, String> distList = new HashMap<Integer, String>();
		distList.put(1, "Kolkata");
		distList.put(2, "Darjeeling");
		distList.put(3, "North24Paraganas");
		district.setDList(distList);
		return district.getDList();
	}

//GET method to explore districts based on district name along with list of parties
	@RequestMapping(value = "/expDist", method = RequestMethod.GET)
	public ArrayList<Object> DistKol(@RequestParam(value = "district") String districtInput) {
		Districts district = new Districts();
		HashMap<String, String> distParty = new HashMap<String, String>();
		ArrayList<Object> dist = new ArrayList<Object>();
		if (districtInput.equalsIgnoreCase("Kolkata")) {
		district.setDElecDate("11/11/1111");
		district.setDid(1);
		district.setDName("Kolkata");
		distParty.put("A", "AM");
		distParty.put("B", "BM");
		distParty.put("C", "CM");
		district.setDParty(distParty);
		dist.add(district.getDName());
		dist.add(district.getDid());
		dist.add(district.getDElecDate());
		dist.add(district.getDParty());
		}
		else if(districtInput.equalsIgnoreCase("Darjeeling")) {
		district.setDElecDate("22/22/2222");
		district.setDid(1);
		district.setDName("Darjeeling");
		distParty.put("A", "AM");
		distParty.put("B", "BM");
		distParty.put("C", "CM");
		district.setDParty(distParty);
		dist.add(district.getDName());
		dist.add(district.getDid());
		dist.add(district.getDElecDate());
		dist.add(district.getDParty());	
		}
		else {
			district.setDElecDate("33/33/3333");
			district.setDid(1);
			district.setDName("Others");
			distParty.put("A", "AM");
			distParty.put("B", "BM");
			distParty.put("C", "CM");
			district.setDParty(distParty);
			dist.add(district.getDName());
			dist.add(district.getDid());
			dist.add(district.getDElecDate());
			dist.add(district.getDParty());	
			}
		return dist;
	}

//POST method for submitting vote by voter
	@RequestMapping(value = "/voting", method = RequestMethod.POST)
	public String Voting(@RequestBody Election inputStream) {
		String response = "The voter with name "+inputStream.getVoter()+" has voted for "
				+inputStream.getPartyMmber()+" belonging to "+inputStream.getParty()
				+" party from the district "+inputStream.getDistrict()+" successfully!!";
		return response;
	}
	
//GET method to see results based on district
	@RequestMapping(value = "/ElectResults", method = RequestMethod.GET)
	public Election ElecRes(@RequestParam(value = "district") String district) {
		Election election = new Election();
		if(district.equalsIgnoreCase("Kolkata")) {
		election.setDistrict("Kolkata");
		election.setParty("A");
		election.setPartyMmber("AM");
		election.setVotes("56%");
		}
		else if(district.equalsIgnoreCase("Darjeeling")) {
		election.setDistrict("Darjeeling");
		election.setParty("B");
		election.setPartyMmber("BM");
		election.setVotes("24%");
		}
		else {
		election.setDistrict("Others");
		election.setParty("C");
		election.setPartyMmber("CM");
		election.setVotes("20%");
		}
		return election;
	}
}
